from .functions import get_jsons, get_jsons_from_our_db, add_to_inform_ocenka_all, add_to_our_inform_ocenka_all,copy_data_to_our_bd, delete_from_armr_db
__all__ = [
'get_jsons',
'get_jsons_from_our_db',
'add_to_inform_ocenka_all',
'add_to_our_inform_ocenka_all',
'copy_data_to_our_bd',
'delete_from_armr_db'
]
