from .functions import interquartile_clean

__all__ = ['interquartile_clean']
